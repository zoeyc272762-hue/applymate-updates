﻿param(
  [string]$SourceDir = $PSScriptRoot,
  [string]$InstallRoot = '',
  [switch]$PrepareOnly,
  [switch]$CheckOnly,
  [switch]$NoOpen
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$script:ExtId = 'feekflfaeiopmljagbabmmpahehkaelg'
$script:Version = '0.3.1'

if ([string]::IsNullOrWhiteSpace($InstallRoot)) {
  $InstallRoot = Join-Path $env:LOCALAPPDATA 'ApplyMate-Offline'
}
$script:InstallRoot = $InstallRoot
$script:ExtDir = Join-Path $InstallRoot 'extension'
$script:SourceDir = $SourceDir
$script:NoOpen = [bool]$NoOpen

$script:ExcludedNames = @(
  'Install-ApplyMate-Daily.ps1',
  '安装到日常Edge.cmd',
  'Start-ApplyMate-Offline.cmd',
  'Update-ApplyMate-Offline.ps1',
  'Update-ApplyMate-Daily.ps1',
  '更新-ApplyMate-离线版.cmd',
  'update-config.json',
  '安装说明.txt'
)

function Find-Edge {
  $candidates = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
  )
  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate)) {
      return $candidate
    }
  }
  return ''
}

function Normalize-FolderPath {
  param([string]$Path)
  if ([string]::IsNullOrWhiteSpace($Path)) { return '' }
  try {
    return ([IO.Path]::GetFullPath($Path)).TrimEnd('\').ToLowerInvariant()
  } catch {
    return $Path.TrimEnd('\').ToLowerInvariant()
  }
}

function Copy-ExtensionPayload {
  $staging = Join-Path ([IO.Path]::GetTempPath()) ('applymate-stage-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $staging | Out-Null
  try {
    Get-ChildItem -LiteralPath $script:SourceDir -Force | Where-Object {
      $script:ExcludedNames -notcontains $_.Name
    } | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $staging -Recurse -Force -ErrorAction Stop
    }
    if (!(Test-Path -LiteralPath (Join-Path $staging 'manifest.json'))) {
      throw '安装包不完整：找不到 manifest.json。请重新解压完整的离线包后再运行。'
    }

    New-Item -ItemType Directory -Force -Path $script:ExtDir | Out-Null
    $null = & robocopy.exe $staging $script:ExtDir /MIR /NFL /NDL /NJH /NJS /NP /R:2 /W:1 2>&1
    $code = $LASTEXITCODE
    if ($code -ge 8) {
      throw "无法写入安装目录（错误码 $code）。请先关闭 Edge 浏览器，然后重新运行安装脚本。"
    }
  } finally {
    Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
  }
}

function Copy-RuntimeFiles {
  New-Item -ItemType Directory -Force -Path $script:InstallRoot | Out-Null
  foreach ($name in @(
    'update-config.json',
    'Update-ApplyMate-Daily.ps1',
    'Update-ApplyMate-Offline.ps1',
    '更新-ApplyMate-离线版.cmd',
    '安装说明.txt'
  )) {
    $source = Join-Path $script:SourceDir $name
    if (Test-Path -LiteralPath $source) {
      Copy-Item -LiteralPath $source -Destination (Join-Path $script:InstallRoot $name) -Force
    }
  }

  $openCmd = @"
@echo off
setlocal
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" (
  echo Microsoft Edge was not found.
  pause
  exit /b 1
)
start "" "%EDGE%" "chrome-extension://$script:ExtId/dashboard.html#/welcome"
endlocal
"@
  $openCmdPath = Join-Path $script:InstallRoot '打开-ApplyMate.cmd'
  [IO.File]::WriteAllText($openCmdPath, ($openCmd -replace "`r?`n", "`r`n"), [Text.Encoding]::ASCII)
}

function Get-VersionFromPath {
  param([string]$Folder)
  if ([string]::IsNullOrWhiteSpace($Folder)) { return '' }
  try {
    $manifestPath = Join-Path $Folder 'manifest.json'
    if (Test-Path -LiteralPath $manifestPath) {
      $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
      return [string]$manifest.version
    }
  } catch {
    return ''
  }
  return ''
}

function Get-InstalledProfiles {
  $found = @()
  $userData = Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data'
  if (!(Test-Path -LiteralPath $userData)) { return $found }

  $profiles = @(Get-ChildItem -LiteralPath $userData -Directory -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -eq 'Default' -or $_.Name -like 'Profile *'
  })

  foreach ($profile in $profiles) {
    # Edge keeps unpacked-extension settings in "Secure Preferences";
    # Chrome and some Edge versions also write "Preferences".
    foreach ($fileName in @('Secure Preferences', 'Preferences')) {
      $pref = Join-Path $profile.FullName $fileName
      if (!(Test-Path -LiteralPath $pref)) { continue }
      $matched = $false
      foreach ($attempt in 1..3) {
        try {
          $json = Get-Content -LiteralPath $pref -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
          if ($json.extensions -and $json.extensions.settings) {
            $property = $json.extensions.settings.PSObject.Properties[$script:ExtId]
            if ($property) {
              $setting = $property.Value
              $state = if ($null -ne $setting.state) { $setting.state } else { 1 }
              $installedVersion = if ($setting.manifest -and $setting.manifest.version) {
                [string]$setting.manifest.version
              } else {
                Get-VersionFromPath ([string]$setting.path)
              }
              $found += [pscustomobject]@{
                Profile = $profile.Name
                Path = [string]$setting.path
                State = $state
                InstalledVersion = $installedVersion
              }
              $matched = $true
            }
          }
          break
        } catch {
          Start-Sleep -Milliseconds 250
        }
      }
      if ($matched) { break }
    }
  }
  return $found
}

function New-DesktopShortcut {
  $desktop = [Environment]::GetFolderPath('Desktop')
  if ([string]::IsNullOrWhiteSpace($desktop)) { return }
  $shortcutPath = Join-Path $desktop 'ApplyMate 离线版.lnk'
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($shortcutPath)
  $shortcut.TargetPath = $script:EdgePath
  $shortcut.Arguments = "chrome-extension://$script:ExtId/dashboard.html#/welcome"
  $shortcut.WorkingDirectory = $script:InstallRoot
  $shortcut.Description = 'ApplyMate 离线版'
  $shortcut.IconLocation = "$script:EdgePath,0"
  $shortcut.Save()
}

function Show-Fatal {
  param([string]$Message)
  try {
    Add-Type -AssemblyName System.Windows.Forms
    [void][System.Windows.Forms.MessageBox]::Show(
      $Message,
      'ApplyMate 安装失败',
      [System.Windows.Forms.MessageBoxButtons]::OK,
      [System.Windows.Forms.MessageBoxIcon]::Error
    )
  } catch {
    Write-Host $Message
  }
}

function Show-InstallerUi {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  try {
    Add-Type @'
using System.Runtime.InteropServices;
public class ApplyMateDpi {
  [DllImport("user32.dll")]
  public static extern bool SetProcessDPIAware();
}
'@
    [void][ApplyMateDpi]::SetProcessDPIAware()
  } catch {
    # If the process is already DPI-aware, Windows Forms still works.
  }
  [System.Windows.Forms.Application]::EnableVisualStyles()

  $form = New-Object System.Windows.Forms.Form
  $form.Text = 'ApplyMate 离线版安装向导'
  $form.ClientSize = New-Object System.Drawing.Size(650, 690)
  $form.StartPosition = 'CenterScreen'
  $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
  $form.MaximizeBox = $false
  $form.MinimizeBox = $false
  $form.TopMost = $true
  $form.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
  $script:Form = $form

  $title = New-Object System.Windows.Forms.Label
  $title.Text = 'ApplyMate 离线版'
  $title.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 15, [System.Drawing.FontStyle]::Bold)
  $title.Location = New-Object System.Drawing.Point(22, 14)
  $title.AutoSize = $false
  $title.Size = New-Object System.Drawing.Size(600, 40)
  $form.Controls.Add($title)

  $subtitle = New-Object System.Windows.Forms.Label
  $subtitle.Text = "v$script:Version · 安装到日常 Edge（推荐）"
  $subtitle.ForeColor = [System.Drawing.Color]::FromArgb(71, 85, 105)
  $subtitle.Location = New-Object System.Drawing.Point(24, 58)
  $subtitle.AutoSize = $false
  $subtitle.Size = New-Object System.Drawing.Size(600, 24)
  $subtitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
  $form.Controls.Add($subtitle)

  $pathLabel = New-Object System.Windows.Forms.Label
  $pathLabel.Text = '安装位置（请点“复制路径”后再粘贴）：'
  $pathLabel.Location = New-Object System.Drawing.Point(24, 92)
  $pathLabel.AutoSize = $true
  $form.Controls.Add($pathLabel)

  $pathBox = New-Object System.Windows.Forms.TextBox
  $pathBox.Text = $script:ExtDir
  $pathBox.Location = New-Object System.Drawing.Point(24, 114)
  $pathBox.Size = New-Object System.Drawing.Size(600, 26)
  $pathBox.ReadOnly = $true
  $pathBox.Font = New-Object System.Drawing.Font('Consolas', 9)
  $pathBox.TabStop = $false
  $pathBox.SelectionStart = 0
  $form.Controls.Add($pathBox)

  $steps = New-Object System.Windows.Forms.Label
  $steps.AutoSize = $false
  $steps.Location = New-Object System.Drawing.Point(24, 156)
  $steps.Size = New-Object System.Drawing.Size(600, 232)
  $steps.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 10)
  $steps.Text = @"
请按下面 5 步操作（扩展页和安装文件夹已经自动打开）：

1. 在 Edge 扩展页右上角，打开「开发人员模式」。
2. 点击「加载解压缩的扩展」。
3. 点本窗口的「复制路径」，再到文件夹选择窗口按 Ctrl+V，然后回车。
4. 选中 extension 文件夹，点击「选择文件夹」。
5. 回到本窗口，点击下面的「检查安装」。

如果之前装过 ApplyMate，请在扩展卡片上点击刷新按钮「↻」。
以后更新时，双击安装目录里的「更新-ApplyMate-离线版.cmd」。
"@
  $form.Controls.Add($steps)

  $status = New-Object System.Windows.Forms.Label
  $status.Text = '等待安装…'
  $status.Location = New-Object System.Drawing.Point(24, 394)
  $status.Size = New-Object System.Drawing.Size(600, 64)
  $status.ForeColor = [System.Drawing.Color]::FromArgb(100, 116, 139)
  $script:StatusLabel = $status
  $form.Controls.Add($status)

  $btnEdge = New-Object System.Windows.Forms.Button
  $btnEdge.Text = '打开扩展页'
  $btnEdge.Location = New-Object System.Drawing.Point(24, 466)
  $btnEdge.Size = New-Object System.Drawing.Size(120, 34)
  $form.Controls.Add($btnEdge)

  $btnFolder = New-Object System.Windows.Forms.Button
  $btnFolder.Text = '打开文件夹'
  $btnFolder.Location = New-Object System.Drawing.Point(154, 466)
  $btnFolder.Size = New-Object System.Drawing.Size(120, 34)
  $form.Controls.Add($btnFolder)

  $btnCopy = New-Object System.Windows.Forms.Button
  $btnCopy.Text = '复制路径'
  $btnCopy.Location = New-Object System.Drawing.Point(284, 466)
  $btnCopy.Size = New-Object System.Drawing.Size(105, 34)
  $form.Controls.Add($btnCopy)

  $btnCheck = New-Object System.Windows.Forms.Button
  $btnCheck.Text = '检查安装'
  $btnCheck.Location = New-Object System.Drawing.Point(399, 466)
  $btnCheck.Size = New-Object System.Drawing.Size(105, 34)
  $form.Controls.Add($btnCheck)

  $btnOpen = New-Object System.Windows.Forms.Button
  $btnOpen.Text = '打开 ApplyMate'
  $btnOpen.Location = New-Object System.Drawing.Point(24, 512)
  $btnOpen.Size = New-Object System.Drawing.Size(170, 34)
  $btnOpen.Enabled = $false
  $script:OpenButton = $btnOpen
  $form.Controls.Add($btnOpen)

  $btnFinish = New-Object System.Windows.Forms.Button
  $btnFinish.Text = '关闭'
  $btnFinish.Location = New-Object System.Drawing.Point(504, 512)
  $btnFinish.Size = New-Object System.Drawing.Size(120, 34)
  $form.Controls.Add($btnFinish)

  $shortcutCheck = New-Object System.Windows.Forms.CheckBox
  $shortcutCheck.Text = '安装成功后创建桌面快捷方式'
  $shortcutCheck.Location = New-Object System.Drawing.Point(24, 562)
  $shortcutCheck.Size = New-Object System.Drawing.Size(480, 24)
  $shortcutCheck.Checked = $true
  $script:ShortcutCheck = $shortcutCheck
  $form.Controls.Add($shortcutCheck)

  $note = New-Object System.Windows.Forms.Label
  $note.Text = '安装文件固定保存在本机，移动或删除下载的压缩包不会影响扩展。档案和申请记录保存在 Edge 本地，不会上传。'
  $note.Location = New-Object System.Drawing.Point(24, 596)
  $note.Size = New-Object System.Drawing.Size(600, 50)
  $note.ForeColor = [System.Drawing.Color]::FromArgb(100, 116, 139)
  $form.Controls.Add($note)

  $btnEdge.Add_Click({
    Start-Process -FilePath $script:EdgePath -ArgumentList 'edge://extensions'
  })
  $btnFolder.Add_Click({
    Start-Process -FilePath 'explorer.exe' -ArgumentList $script:ExtDir
  })
  $btnCopy.Add_Click({
    try {
      [System.Windows.Forms.Clipboard]::SetText($script:ExtDir)
      $script:StatusLabel.Text = '安装路径已复制。请在 Edge 的文件夹选择窗口按 Ctrl+V 粘贴。'
      $script:StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(37, 99, 235)
    } catch {
      $script:StatusLabel.Text = '复制失败，请手动选中上方路径复制。'
      $script:StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(180, 83, 9)
    }
  })
  $btnCheck.Add_Click({
    $script:StatusLabel.Text = '正在检查安装状态…'
    $script:StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(100, 116, 139)
    Start-Sleep -Milliseconds 400
    $installed = @(Get-InstalledProfiles)
    if ($installed.Count -gt 0) {
      $item = $installed[0]
      $stateText = if ($item.State -eq 0) { '（当前被停用，请在扩展页启用）' } else { '' }
      $versionText = if ($item.InstalledVersion) { " v$($item.InstalledVersion)" } else { '' }
      $script:StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(21, 128, 61)
      $script:StatusLabel.Text = "已检测到 ApplyMate$versionText 安装在 $($item.Profile) 配置中$stateText。"
      $script:OpenButton.Enabled = $true

      $installedPath = Normalize-FolderPath $item.Path
      $expectedPath = Normalize-FolderPath $script:ExtDir
      if ($installedPath -and $installedPath -ne $expectedPath) {
        $script:StatusLabel.Text += "`r`n注意：扩展当前从旧目录加载。建议在扩展页移除后，从固定目录重新加载，否则以后更新不会生效。"
        $script:StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(180, 83, 9)
      } elseif ($item.InstalledVersion -and $item.InstalledVersion -ne $script:Version) {
        $script:StatusLabel.Text += "`r`n安装文件已是 v$script:Version，请点击扩展卡片上的刷新按钮「↻」应用新版本。"
        $script:StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(180, 83, 9)
      }

      if ($script:ShortcutCheck.Checked) {
        try {
          New-DesktopShortcut
          $script:StatusLabel.Text += "`r`n已在桌面创建快捷方式。"
        } catch {
          $script:StatusLabel.Text += "`r`n桌面快捷方式创建失败，不影响扩展使用。"
        }
      }
    } else {
      $script:StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(180, 83, 9)
      $script:StatusLabel.Text = '还没有检测到安装。请确认：已开启「开发人员模式」、在文件夹选择窗口粘贴的是上面的 extension 路径、并点击了「选择文件夹」。然后再点一次「检查安装」。'
    }
  })
  $btnOpen.Add_Click({
    Start-Process -FilePath $script:EdgePath -ArgumentList "chrome-extension://$script:ExtId/dashboard.html#/welcome"
  })
  $btnFinish.Add_Click({
    $script:Form.Close()
  })

  $form.Add_Shown({
    if (!$script:NoOpen) {
      Start-Process -FilePath 'explorer.exe' -ArgumentList $script:ExtDir
      Start-Process -FilePath $script:EdgePath -ArgumentList 'edge://extensions'
    }
  })

  [void]$form.ShowDialog()
  $form.Dispose()
}

try {
  $script:EdgePath = Find-Edge
  if (!$script:EdgePath) {
    throw '没有找到 Microsoft Edge。请先安装 Edge 浏览器。'
  }
  if (!(Test-Path -LiteralPath (Join-Path $script:SourceDir 'manifest.json'))) {
    throw '安装包不完整：找不到 manifest.json。请重新解压完整的离线包后再运行。'
  }

  if ($CheckOnly) {
    $installed = @(Get-InstalledProfiles)
    if ($installed.Count -eq 0) {
      Write-Output 'not-installed'
      exit 0
    }
    foreach ($item in $installed) {
      Write-Output ("profile={0};path={1};state={2};version={3}" -f $item.Profile, $item.Path, $item.State, $item.InstalledVersion)
    }
    exit 0
  }

  Copy-ExtensionPayload
  Copy-RuntimeFiles

  if ($PrepareOnly) {
    Write-Output "prepared=$script:ExtDir"
    Write-Output "version=$script:Version"
    Write-Output "edge=$script:EdgePath"
    exit 0
  }

  Show-InstallerUi
  exit 0
} catch {
  if ($PrepareOnly) {
    Write-Error $_.Exception.Message
    exit 1
  }
  Show-Fatal $_.Exception.Message
  exit 1
}
