@echo off
setlocal
chcp 65001 >nul
title ApplyMate Installer
powershell -STA -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-ApplyMate-Daily.ps1" -SourceDir "%~dp0"
if errorlevel 1 (
  echo.
  echo Installation preparation failed. Please read the message above.
  pause
)
endlocal
