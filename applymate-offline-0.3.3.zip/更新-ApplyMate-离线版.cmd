@echo off
setlocal
chcp 65001 >nul
title ApplyMate Update
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-ApplyMate-Daily.ps1" -InstallRoot "%LOCALAPPDATA%\ApplyMate-Offline"
if errorlevel 1 (
  echo.
  echo Update failed. Please read the message above.
)
echo.
pause
endlocal
