﻿param(
  [string]$InstallRoot = '',
  [switch]$NoOpen
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }

$script:ExtId = 'feekflfaeiopmljagbabmmpahehkaelg'
if ([string]::IsNullOrWhiteSpace($InstallRoot)) {
  $InstallRoot = Join-Path $env:LOCALAPPDATA 'ApplyMate-Offline'
}
$script:InstallRoot = $InstallRoot
$script:ExtDir = Join-Path $InstallRoot 'extension'
$script:NoOpen = [bool]$NoOpen

$script:ExcludedNames = @(
  'Install-ApplyMate-Daily.ps1',
  '安装到日常Edge.cmd',
  'Start-ApplyMate-Offline.cmd',
  'Update-ApplyMate-Offline.ps1',
  'Update-ApplyMate-Daily.ps1',
  '更新-ApplyMate-离线版.cmd',
  'update-config.json',
  '安装说明.txt'
)

function Find-Edge {
  $candidates = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
  )
  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate)) {
      return $candidate
    }
  }
  return ''
}

function Copy-ExtensionPayload {
  param([string]$From)
  $staging = Join-Path ([IO.Path]::GetTempPath()) ('applymate-update-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $staging | Out-Null
  try {
    Get-ChildItem -LiteralPath $From -Force | Where-Object {
      $script:ExcludedNames -notcontains $_.Name
    } | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $staging -Recurse -Force -ErrorAction Stop
    }
    if (!(Test-Path -LiteralPath (Join-Path $staging 'manifest.json'))) {
      throw '更新包不完整：找不到 manifest.json。'
    }

    $null = & robocopy.exe $staging $script:ExtDir /MIR /NFL /NDL /NJH /NJS /NP /R:2 /W:1 2>&1
    $code = $LASTEXITCODE
    if ($code -ge 8) {
      throw "无法写入安装目录（错误码 $code）。请关闭 Edge 后重新运行更新。"
    }
  } finally {
    Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
  }
}

function Copy-RuntimeFiles {
  param([string]$From)
  foreach ($name in @(
    'update-config.json',
    'Update-ApplyMate-Daily.ps1',
    'Update-ApplyMate-Offline.ps1',
    '更新-ApplyMate-离线版.cmd',
    '安装说明.txt'
  )) {
    $source = Join-Path $From $name
    if (Test-Path -LiteralPath $source) {
      try {
        Copy-Item -LiteralPath $source -Destination (Join-Path $script:InstallRoot $name) -Force -ErrorAction Stop
      } catch {
        Write-Host "提示：暂时无法更新 $name，下次运行更新脚本时会再尝试。" -ForegroundColor DarkYellow
      }
    }
  }
}

function Get-CurrentVersion {
  $manifestPath = Join-Path $script:ExtDir 'manifest.json'
  if (!(Test-Path -LiteralPath $manifestPath)) { return $null }
  $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
  if (!$manifest.version) { return $null }
  return [version]$manifest.version
}

function Compare-Version {
  param([version]$A, [version]$B)
  return $A.CompareTo($B)
}

try {
  $edge = Find-Edge
  if (!$edge) { throw '没有找到 Microsoft Edge。' }

  $currentVersion = Get-CurrentVersion
  if (!$currentVersion) {
    throw "没有在 $script:ExtDir 找到已安装的离线版。请先运行「安装到日常Edge.cmd」。"
  }

  $configPath = Join-Path $script:InstallRoot 'update-config.json'
  if (!(Test-Path -LiteralPath $configPath)) {
    throw '找不到 update-config.json，无法检查更新。请重新运行安装脚本。'
  }
  $config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
  $feedUrl = [string]$config.feedUrl
  if ([string]::IsNullOrWhiteSpace($feedUrl)) {
    throw '当前安装包没有配置更新源，请从分发者处获取新版本安装包。'
  }

  Write-Host "当前版本：v$currentVersion" -ForegroundColor Cyan
  Write-Host "正在检查更新…"
  try {
    $feedResponse = Invoke-WebRequest -Uri $feedUrl -Headers @{
      'User-Agent' = 'ApplyMate-Updater'
      'Accept' = 'application/vnd.github.raw'
    } -TimeoutSec 20 -UseBasicParsing
    $feedText = if ($feedResponse.Content -is [byte[]]) {
      [System.Text.Encoding]::UTF8.GetString($feedResponse.Content)
    } else {
      [string]$feedResponse.Content
    }
    $feed = $feedText | ConvertFrom-Json
  } catch {
    throw '检查更新失败，请确认网络连接后重试。'
  }

  if (!$feed -or !$feed.version) { throw '更新源返回的版本信息不完整。' }
  $latestVersion = [version]$feed.version
  if ((Compare-Version $latestVersion $currentVersion) -le 0) {
    Write-Host "已经是最新版本 v$currentVersion。" -ForegroundColor Green
    if (!$script:NoOpen) {
      Start-Process -FilePath $edge -ArgumentList "chrome-extension://$script:ExtId/dashboard.html#/welcome"
    }
    exit 0
  }

  $downloadUrl = [string]$feed.downloadUrl
  if ($downloadUrl -notmatch '^https?://') {
    $base = New-Object System.Uri($feedUrl)
    $downloadUrl = (New-Object System.Uri($base, $downloadUrl)).AbsoluteUri
  }

  $updatesDir = Join-Path $script:InstallRoot 'updates'
  New-Item -ItemType Directory -Force -Path $updatesDir | Out-Null
  $zipPath = Join-Path $updatesDir ("applymate-offline-" + $latestVersion.ToString() + ".zip")
  Write-Host "发现新版本 v$latestVersion，正在下载…"
  try {
    Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath -Headers @{
      'User-Agent' = 'ApplyMate-Updater'
    } -TimeoutSec 90 -UseBasicParsing
  } catch {
    throw '下载安装包失败，请检查网络后重试。'
  }

  if ($feed.sha256) {
    $hash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne ([string]$feed.sha256).ToLowerInvariant()) {
      Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
      throw '安装包校验失败（SHA-256 不一致），已取消更新。'
    }
  }

  $extractDir = Join-Path $script:InstallRoot ('staging-' + $latestVersion.ToString())
  if (Test-Path -LiteralPath $extractDir) {
    Remove-Item -LiteralPath $extractDir -Recurse -Force
  }
  New-Item -ItemType Directory -Force -Path $extractDir | Out-Null
  try {
    Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force
  } catch {
    throw '解压安装包失败，请重新下载后再试。'
  }
  if (!(Test-Path -LiteralPath (Join-Path $extractDir 'manifest.json'))) {
    throw '安装包内容不完整，已取消更新。'
  }

  Copy-ExtensionPayload -From $extractDir
  Copy-RuntimeFiles -From $extractDir
  [IO.File]::WriteAllText(
    (Join-Path $script:InstallRoot 'current-version.txt'),
    $latestVersion.ToString(),
    (New-Object System.Text.UTF8Encoding($false))
  )

  Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue

  Write-Host "已更新到 v$latestVersion。" -ForegroundColor Green
  Write-Host ''
  Write-Host '最后一步：回到 Edge 扩展页，在 ApplyMate 卡片上点击刷新按钮「↻」，然后重新打开 ApplyMate。' -ForegroundColor Yellow
  if (!$script:NoOpen) {
    Start-Process -FilePath $edge -ArgumentList 'edge://extensions'
  }
  exit 0
} catch {
  Write-Host ''
  Write-Host $_.Exception.Message -ForegroundColor Red
  exit 1
}
