"use strict";
(() => {
  // src/content/dom.ts
  function waitForDomStable(idleMs = 260, timeoutMs = 1600) {
    return new Promise((resolve) => {
      let idleTimer = window.setTimeout(done, idleMs);
      let hardTimer = window.setTimeout(done, timeoutMs);
      let observer = null;
      let finished = false;
      function done() {
        if (finished) return;
        finished = true;
        window.clearTimeout(idleTimer);
        window.clearTimeout(hardTimer);
        observer?.disconnect();
        resolve();
      }
      try {
        observer = new MutationObserver(() => {
          window.clearTimeout(idleTimer);
          idleTimer = window.setTimeout(done, idleMs);
        });
        observer.observe(document.documentElement, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["style", "class", "hidden", "disabled"]
        });
      } catch {
        done();
      }
    });
  }

  // ../packages/shared/src/format.ts
  var pad = (n) => String(n).padStart(2, "0");
  function parseDateParts(input) {
    if (!input) return null;
    const s = String(input).trim();
    if (!s) return null;
    let m = s.match(/^(\d{4})\s*[-/.年]\s*(\d{1,2})(?:\s*[-/.月]\s*(\d{1,2}))?\s*日?$/);
    if (m) {
      const month = +m[2];
      const day = m[3] ? +m[3] : void 0;
      if (month < 1 || month > 12 || day != null && (day < 1 || day > 31)) return null;
      return { year: +m[1], month, day };
    }
    if (/^\d{4}$/.test(s)) return { year: +s };
    m = s.match(/^(\d{1,2})\s*[-/.]\s*(\d{4})$/);
    if (m) return { year: +m[2], month: +m[1] };
    m = s.match(/^([A-Za-z]{3,9})\.?\s+(\d{4})$/);
    if (m) {
      const idx = MONTH_NAMES.findIndex((n) => n.startsWith(m[1].slice(0, 3).toLowerCase()));
      if (idx >= 0) return { year: +m[2], month: idx + 1 };
    }
    return null;
  }
  var MONTH_NAMES = [
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december"
  ];
  function formatDate(input, style = "iso") {
    const p = parseDateParts(input);
    if (!p) return (input ?? "").toString();
    const { year, month, day } = p;
    if (style === "year") return String(year);
    if (style === "yearMonth") return month ? `${year}-${pad(month)}` : String(year);
    if (!month) return String(year);
    const dd = day ?? 1;
    switch (style) {
      case "zh":
        return `${year}\u5E74${pad(month)}\u6708${pad(dd)}\u65E5`;
      case "us":
        return `${pad(month)}/${pad(dd)}/${year}`;
      case "eu":
        return `${pad(dd)}/${pad(month)}/${year}`;
      default:
        return `${year}-${pad(month)}-${pad(dd)}`;
    }
  }
  function formatDateForField(value, hints = {}) {
    const p = parseDateParts(value);
    if (!p) return (value ?? "").toString();
    const hay = `${hints.placeholder ?? ""} ${hints.label ?? ""}`.toLowerCase();
    if (hints.inputType === "date") return formatDate(value, "iso");
    if (hints.inputType === "month") return formatDate(value, "yearMonth");
    const hasDay = p.day != null;
    if (/mm\s*\/\s*dd\s*\/\s*yyyy|月\/日\/年/.test(hay)) return formatDate(value, "us");
    if (/dd\s*\/\s*mm\s*\/\s*yyyy|日\/月\/年/.test(hay)) return formatDate(value, "eu");
    if (/(^|[^a-z])yyyy\s*[-/年]\s*mm($|[^d])/.test(hay) || /年\s*月(?!.*日)/.test(hay)) {
      return formatDate(value, "yearMonth");
    }
    if (/出生|birth|dob/i.test(hay) && hasDay) return formatDate(value, "iso");
    if (/毕业|graduat/i.test(hay)) return hasDay ? formatDate(value, "zh") : formatDate(value, "yearMonth");
    if (/[一-龥]/.test(hints.label ?? "")) return formatDate(value, "zh");
    return hasDay ? formatDate(value, "iso") : formatDate(value, "yearMonth");
  }
  function normalizeText(input) {
    return String(input ?? "").replace(/[！-～]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 65248)).replace(/　/g, " ").toLowerCase().replace(/\s+/g, "").replace(/[*＊:：,.，。!！?？'"“”‘’()（）[\]【】{}<>《》_\-–—/\\|]/g, "");
  }
  function humanizeName(raw) {
    return String(raw ?? "").replace(/[_\-.:[\]]+/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/\d+/g, " ").replace(/\s+/g, " ").trim();
  }
  function isBlank(v) {
    if (v == null) return true;
    if (Array.isArray(v)) return v.every(isBlank);
    return String(v).trim() === "";
  }

  // ../packages/shared/src/options.ts
  var CONCEPTS = {
    male: ["male", "man", "m", "\u7537", "\u7537\u6027", "\u5148\u751F", "mr"],
    female: ["female", "woman", "f", "\u5973", "\u5973\u6027", "\u5973\u58EB", "ms", "miss", "mrs"],
    other_gender: ["other", "prefer not to say", "\u5176\u4ED6", "\u4E0D\u613F\u900F\u9732"],
    yes: ["yes", "y", "true", "\u662F", "\u6709", "\u540C\u610F", "\u613F\u610F", "\u63A5\u53D7", "i agree", "agree"],
    no: ["no", "n", "false", "\u5426", "\u65E0", "\u6CA1\u6709", "\u4E0D\u540C\u610F", "\u4E0D\u63A5\u53D7", "disagree"],
    high_school: ["high school", "senior high", "\u9AD8\u4E2D", "\u4E2D\u4E13", "\u804C\u9AD8"],
    associate: ["associate", "associate degree", "\u5927\u4E13", "\u4E13\u79D1", "\u9AD8\u804C", "\u526F\u5B66\u58EB"],
    bachelor: [
      "bachelor",
      "bachelor's",
      "bachelors",
      "undergraduate",
      "b.s.",
      "b.a.",
      "bs",
      "ba",
      "\u672C\u79D1",
      "\u5B66\u58EB",
      "\u5927\u5B66\u672C\u79D1"
    ],
    master: ["master", "master's", "masters", "m.s.", "m.a.", "msc", "mba", "\u7855\u58EB", "\u7814\u7A76\u751F", "\u7855\u58EB\u7814\u7A76\u751F"],
    doctorate: ["phd", "ph.d.", "doctorate", "doctoral", "\u535A\u58EB", "\u535A\u58EB\u7814\u7A76\u751F"],
    postdoc: ["postdoc", "postdoctoral", "\u535A\u58EB\u540E"],
    full_time: ["full-time", "full time", "fulltime", "\u5168\u65E5\u5236", "\u5168\u804C"],
    part_time: ["part-time", "part time", "parttime", "\u975E\u5168\u65E5\u5236", "\u517C\u804C", "\u5728\u804C"],
    intern: ["intern", "internship", "\u5B9E\u4E60", "\u5B9E\u4E60\u751F"],
    contract: ["contract", "contractor", "\u5408\u540C\u5236", "\u5916\u5305"],
    campus: ["campus", "on-campus", "\u6821\u56ED", "\u6821\u62DB", "\u6821\u56ED\u62DB\u8058"],
    social: ["social", "experienced", "\u793E\u62DB", "\u793E\u4F1A\u62DB\u8058"],
    party_member: ["\u4E2D\u5171\u515A\u5458", "\u515A\u5458", "cpc member", "communist party member"],
    probationary_member: ["\u4E2D\u5171\u9884\u5907\u515A\u5458", "\u9884\u5907\u515A\u5458", "probationary member"],
    league_member: ["\u5171\u9752\u56E2\u5458", "\u56E2\u5458", "league member", "cylc member"],
    masses: ["\u7FA4\u4F17", "\u666E\u901A\u7FA4\u4F17", "masses"],
    democratic_party: ["\u6C11\u4E3B\u515A\u6D3E", "democratic party"],
    undergraduate_institution: ["\u53CC\u4E00\u6D41", "985", "211"]
  };
  var CONCEPT_BY_VALUE = /* @__PURE__ */ new Map();
  for (const [concept, values] of Object.entries(CONCEPTS)) {
    for (const v of values) CONCEPT_BY_VALUE.set(normalizeText(v), concept);
  }
  function canonicalConcept(value) {
    return CONCEPT_BY_VALUE.get(normalizeText(value)) ?? null;
  }
  function matchOption(value, options) {
    if (!value || !options?.length) return null;
    const nv = normalizeText(value);
    if (!nv) return null;
    for (const option of options) {
      if (!option.disabled && (normalizeText(option.value) === nv || normalizeText(option.label) === nv)) {
        return { option, confidence: 1, reason: "exact" };
      }
    }
    const concept = canonicalConcept(value);
    if (concept) {
      for (const option of options) {
        if (option.disabled) continue;
        if (canonicalConcept(option.label) === concept || canonicalConcept(option.value) === concept) {
          return { option, confidence: 0.92, reason: "synonym" };
        }
      }
    }
    let best = null;
    for (const option of options) {
      if (option.disabled) continue;
      const nl = normalizeText(option.label);
      if (!nl) continue;
      if (nl.includes(nv) || nv.length >= 2 && nv.includes(nl)) {
        const conf = 0.78;
        if (!best || conf > best.confidence) best = { option, confidence: conf, reason: "contains" };
      }
    }
    return best;
  }

  // ../packages/shared/src/rules.ts
  var strOf = (v) => typeof v === "string" && v.trim() ? v.trim() : null;
  function itemAt(profile, group, index) {
    return profile[group][index];
  }
  function mostRecentEducation(profile) {
    const scored = profile.educations.map((e) => ({ e, score: e.endDate || e.startDate || "" })).sort((a, b) => a.score < b.score ? 1 : -1);
    return scored[0]?.e;
  }
  function classifySection(section) {
    const s = normalizeText(section);
    if (!s) return null;
    if (/教育|学历|学校|院校|在校|求学|education|academic|school|university/.test(s)) return "educations";
    if (/实习|工作经历|工作经验|任职|就职|职业|employment|workexperience|internship|career|professionalexperience/.test(s))
      return "internships";
    if (/项目|project/.test(s)) return "projects";
    if (/校园|社团|学生工作|校内|课外|activities|campus|leadership|extracurricular|studentorg/.test(s))
      return "campusExperiences";
    if (/荣誉|奖励|获奖|奖项|award|honor|achievement/.test(s)) return "honors";
    if (/技能|证书|语言能力|资格|skill|certif|language/.test(s)) return "skills";
    if (/问答|问题|自述|开放题|essay|question|additionalquestion|opendended/.test(s)) return "customAnswers";
    if (/基本|个人信息|联系方式|个人资料|personal|contact|profile/.test(s)) return "basic";
    return null;
  }
  var GROUP_LEAVES = {
    educations: /* @__PURE__ */ new Set([
      "school",
      "degree",
      "major",
      "studyMode",
      "startDate",
      "endDate",
      "gpa",
      "ranking",
      "city",
      "description"
    ]),
    internships: /* @__PURE__ */ new Set(["company", "title", "startDate", "endDate", "city", "description"]),
    projects: /* @__PURE__ */ new Set(["name", "role", "description", "responsibilities"]),
    campusExperiences: /* @__PURE__ */ new Set(["organization", "title", "startDate", "endDate", "description"])
  };
  function arrayRule(id, group, leaf, pattern, opts = {}) {
    return {
      id,
      group,
      requireGroup: [group],
      pattern,
      negative: opts.negative,
      base: opts.base ?? 0.92,
      resolve: (ctx) => {
        const arr = ctx.profile[group];
        let item = itemAt(ctx.profile, group, ctx.index);
        if (opts.indexMode === "latest" && group === "educations") {
          item = mostRecentEducation(ctx.profile);
        }
        if (!item) return null;
        if (!GROUP_LEAVES[group].has(leaf)) return null;
        const v = strOf(item[leaf]);
        if (!v) return null;
        const idx = opts.indexMode === "latest" ? ctx.profile.educations.indexOf(mostRecentEducation(ctx.profile)) : ctx.index;
        return { path: `${group}[${idx}].${leaf}`, value: v };
      }
    };
  }
  function basicRule(id, key, pattern, opts = {}) {
    return {
      id,
      group: "basic",
      pattern,
      negative: opts.negative,
      kinds: opts.kinds,
      base: opts.base ?? 0.93,
      resolve: (ctx) => {
        const raw = ctx.profile.basic[key];
        const v = strOf(raw);
        if (!v) return null;
        return { path: `basic.${key}`, value: v };
      }
    };
  }
  var generatedRule = (id, pattern, fn, opts = {}) => ({
    id,
    pattern,
    negative: opts.negative,
    kinds: opts.kinds,
    base: opts.base ?? 0.85,
    resolve: fn
  });
  var AGE_RE = /^(?:age|年龄)$|(?:your|current|applicant)age$|年龄/;
  function calcAge(birthDate) {
    const m = birthDate.match(/^(\d{4})[-/.年](\d{1,2})/);
    if (!m) return null;
    const now = /* @__PURE__ */ new Date();
    const age = now.getFullYear() - Number(m[1]) - (now.getMonth() + 1 < Number(m[2]) ? 1 : 0);
    return age > 0 && age < 120 ? String(age) : null;
  }
  var RULES = [
    // ── Highest priority: ambiguous-but-specific labels ────────────────
    basicRule("confirmEmail", "email", /(confirm|reenter|repeat|verify|再次|确认|重复).*(email|邮箱)|(email|邮箱).*(confirm|again|再次|确认)/, {
      base: 0.95,
      kinds: ["email", "text"]
    }),
    basicRule("fullName", "fullName", /fullname|yourname|applicantname|realname|^name$|姓名|真实姓名|中文姓名/, {
      base: 0.92,
      negative: /first|last|company|school|project|file|user|nick|英文名|拼音|推荐人|联系人|紧急|用户名|昵称|文件|公司|学校|项目/
    }),
    basicRule("email", "email", /email|邮箱|电子邮件|mailaddress/, {
      negative: /confirm|verify|again|reenter|确认|再次|重复/,
      kinds: ["email", "text"]
    }),
    basicRule("phone", "phone", /phone|mobile|cell|telephone|contactnumber|手机|电话|联系方式|联系电话|手机号/, {
      negative: /country|区号|code|ext|分机|emergency|紧急|验证码|verification|code$/,
      kinds: ["tel", "text", "number"]
    }),
    basicRule("countryCode", "countryCode", /countrycode|dialcode|国家代码|国际区号/, { base: 0.9 }),
    basicRule("gender", "gender", /gender|sex$|性别/, { negative: /orientation|取向/ }),
    basicRule("ethnicity", "ethnicity", /ethnicity|race|民族/),
    basicRule("birthDate", "birthDate", /birth|birthday|dateofbirth|dob|出生日期|出生年月|生日/, {
      negative: /place|city|出生地/
    }),
    basicRule("politicalStatus", "politicalStatus", /political|政治面貌|党员|党派/),
    basicRule("city", "city", /city|城市|现居|所在城市|居住地/, { negative: /birth|出生/ }),
    basicRule("address", "address", /address|住址|地址|通讯地址/, { negative: /email|ip|web|url/ }),
    basicRule("englishName", "englishName", /englishname|英文名|英文姓名/),
    basicRule("summary", "summary", /summary|aboutyourself|selfintroduction|personalstatement|自我介绍|个人简介|个人总结|自我评价|个人评价/, {
      negative: /why|coverletter|position|job|职位|岗位/,
      kinds: ["textarea", "text"]
    }),
    // ── Education ──────────────────────────────────────────────────────
    arrayRule("schoolLatest", "educations", "school", /highest|最高学历|最高学位|毕业院校/, {
      indexMode: "latest",
      base: 0.94
    }),
    arrayRule("school", "educations", "school", /school|university|college|institution|院校|学校|就读学校/, {
      negative: /type|类型|性质|company|employer/
    }),
    arrayRule("degree", "educations", "degree", /degree|educationlevel|highestdegree|qualification|学历|学位|学历层次/, {
      base: 0.94
    }),
    arrayRule("major", "educations", "major", /major|fieldofstudy|discipline|specialty|专业|所学专业|主修/, {
      negative: /minor|辅修/
    }),
    arrayRule("studyMode", "educations", "studyMode", /studymode|studytype|fulltime|parttime|学习形式|培养方式|学习方式|就读形式/),
    arrayRule("gpa", "educations", "gpa", /gpa|gradepoint|averagescore|绩点|平均分|平均成绩|学分绩/),
    arrayRule("ranking", "educations", "ranking", /rank|排名|专业排名|年级排名/),
    arrayRule("eduStart", "educations", "startDate", /start|begin|from|入学|开始|起始|就读.*(时间|日期)/, {
      base: 0.88
    }),
    arrayRule("eduEnd", "educations", "endDate", /end|graduat|毕业|结束|离校|预计毕业|完成学业/, { base: 0.88 }),
    // ── Work / internship ─────────────────────────────────────────────
    arrayRule("company", "internships", "company", /company|employer|organization|单位|公司|公司名称|工作单位|实习单位|就职公司/, {
      negative: /school|university|项目|project/
    }),
    arrayRule("jobTitle", "internships", "title", /jobtitle|position|title|职位|岗位|职务|担任职务|实习岗位/, {
      negative: /project|项目/
    }),
    arrayRule("workStart", "internships", "startDate", /start|begin|from|入职|开始|起始/, { base: 0.88 }),
    arrayRule("workEnd", "internships", "endDate", /end|to$|离职|结束|至今|present|current/, { base: 0.88 }),
    arrayRule(
      "workDescription",
      "internships",
      "description",
      /description|responsibilities|duties|workcontent|jobdescription|工作内容|工作描述|工作职责|职责|主要职责|实习内容/,
      { base: 0.85, negative: /project|项目/ }
    ),
    // ── Projects ───────────────────────────────────────────────────────
    arrayRule("projectName", "projects", "name", /projectname|项目名称|项目名|项目$/, { base: 0.94 }),
    arrayRule("projectRole", "projects", "role", /projectrole|角色|担任角色|项目角色/, { base: 0.92 }),
    arrayRule("projectDescription", "projects", "description", /projectdescription|项目介绍|项目描述|项目简介|项目内容|项目背景/, {
      base: 0.9
    }),
    arrayRule("projectResponsibilities", "projects", "responsibilities", /responsibilities|职责|负责内容|主要工作|工作内容|个人职责/, {
      base: 0.84
    }),
    // ── Campus experience ─────────────────────────────────────────────
    arrayRule("campusOrg", "campusExperiences", "organization", /organization|社团|组织|学生组织|学生会|部门|协会/, {
      base: 0.88
    }),
    arrayRule("campusTitle", "campusExperiences", "title", /职务|职位|担任|position|role|title/, { base: 0.88 }),
    arrayRule("campusStart", "campusExperiences", "startDate", /start|begin|from|开始|起始|加入时间/, { base: 0.86 }),
    arrayRule("campusEnd", "campusExperiences", "endDate", /end|to$|结束|至今|present|current/, { base: 0.86 }),
    arrayRule(
      "campusDescription",
      "campusExperiences",
      "description",
      /description|职责|工作内容|主要工作|描述|responsibilities|duties/,
      { base: 0.84 }
    ),
    // ── Honors ────────────────────────────────────────────────────────
    {
      id: "honorName",
      group: "honors",
      requireGroup: ["honors"],
      pattern: /award|honor|奖励|荣誉|奖项|获奖名称|获奖情况/,
      base: 0.92,
      resolve: (ctx) => {
        const h = ctx.profile.honors[ctx.index];
        return h?.name ? { path: `honors[${ctx.index}].name`, value: h.name } : null;
      }
    },
    {
      id: "honorDate",
      group: "honors",
      requireGroup: ["honors"],
      pattern: /date|time|时间|获得时间|获奖时间/,
      base: 0.88,
      resolve: (ctx) => {
        const h = ctx.profile.honors[ctx.index];
        return h?.date ? { path: `honors[${ctx.index}].date`, value: h.date } : null;
      }
    },
    {
      id: "honorLevel",
      group: "honors",
      requireGroup: ["honors"],
      pattern: /level|grade|级别|等级/,
      base: 0.9,
      resolve: (ctx) => {
        const h = ctx.profile.honors[ctx.index];
        return h?.level ? { path: `honors[${ctx.index}].level`, value: h.level } : null;
      }
    },
    {
      id: "honorNote",
      group: "honors",
      requireGroup: ["honors"],
      pattern: /note|remark|备注|说明/,
      base: 0.85,
      resolve: (ctx) => {
        const h = ctx.profile.honors[ctx.index];
        return h?.note ? { path: `honors[${ctx.index}].note`, value: h.note } : null;
      }
    },
    // ── Skills ────────────────────────────────────────────────────────
    {
      id: "certificates",
      group: "skills",
      pattern: /certificate|certification|证书|资格证书|语言证书/,
      kinds: ["text", "textarea", "checkbox", "select"],
      base: 0.88,
      resolve: (ctx) => {
        const certs = ctx.profile.skills.certificates.filter(Boolean);
        if (!certs.length) return null;
        return { path: "skills.certificates[0]", value: certs.join("; ") };
      }
    },
    {
      id: "englishLevel",
      group: "skills",
      pattern: /english|外语|英语|cet|toefl|ielts|四六级|语言能力|languageproficiency/,
      kinds: ["text", "textarea", "select", "checkbox"],
      base: 0.87,
      resolve: (ctx) => {
        const v = strOf(ctx.profile.skills.english);
        return v ? { path: "skills.english", value: v } : null;
      }
    },
    {
      id: "skillsOther",
      group: "skills",
      pattern: /skills|技能|专长|特长|otherskills/,
      kinds: ["text", "textarea", "select", "checkbox"],
      base: 0.85,
      resolve: (ctx) => {
        const v = strOf(ctx.profile.skills.other);
        return v ? { path: "skills.other", value: v } : null;
      }
    },
    // ── Other / additional ────────────────────────────────────────────
    {
      id: "additionalInfo",
      pattern: /additionalinfo|additionalinformation|其他信息|其他说明|补充说明|anythingelse|其他求职|备注/,
      kinds: ["textarea", "text"],
      base: 0.8,
      resolve: (ctx) => {
        const v = strOf(ctx.profile.other.additionalInfo);
        return v ? { path: "other.additionalInfo", value: v } : null;
      }
    }
  ];
  var AGE_RULE = generatedRule(
    "age",
    AGE_RE,
    (ctx) => {
      const birth = strOf(ctx.profile.basic.birthDate);
      if (!birth) return null;
      const age = calcAge(birth);
      return age ? { path: "basic.birthDate", value: age } : null;
    },
    { base: 0.8, kinds: ["number", "text"] }
  );

  // src/content/scanner.ts
  var registry = /* @__PURE__ */ new Map();
  var GROUP_WORDS = {
    basic: /基本|个人|联系|personal|contact|profile|basic/i,
    educations: /教育|学历|学校|院校|education|academic|school/i,
    internships: /实习|工作|任职|经历|employment|work|internship|experience/i,
    projects: /项目|project/i,
    campusExperiences: /校园|社团|学生工作|课外|campus|activities|leadership/i,
    honors: /荣誉|奖励|获奖|award|honor|achievement/i,
    skills: /技能|证书|语言|skill|certif|language/i,
    customAnswers: /问答|问题|自述|essay|question/i,
    other: /其他|备注|additional|other/i
  };
  function cleanLabel(raw) {
    return String(raw ?? "").replace(/\s+/g, " ").replace(/^[\s*＊·•]+/, "").replace(/(?:\(\s*(?:必填|required)\s*\)|（\s*(?:必填|required)\s*）|必填|required)\s*$/i, "").replace(/[\s*＊:：]+$/g, "").trim().slice(0, 300);
  }
  function isVisible(el) {
    const win = el.ownerDocument.defaultView ?? window;
    if (el.closest('[hidden], [aria-hidden="true"]')) return false;
    const style = win.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return false;
    const rect = el.getBoundingClientRect();
    if (rect.width > 1 && rect.height > 1) return true;
    const parent = el.parentElement;
    if (parent) {
      const pr = parent.getBoundingClientRect();
      return pr.width > 1 && pr.height > 1;
    }
    return false;
  }
  function textOf(el) {
    return cleanLabel(el?.textContent ?? "");
  }
  function labelFromAria(el) {
    const doc = el.ownerDocument;
    const labelledby = el.getAttribute("aria-labelledby");
    if (labelledby) {
      const text = labelledby.split(/\s+/).map((id) => textOf(doc.getElementById(id))).filter(Boolean).join(" ");
      if (text) return text;
    }
    return cleanLabel(el.getAttribute("aria-label"));
  }
  function labelFromLabels(el) {
    const labels = el.labels;
    if (labels && labels.length) {
      const text = Array.from(labels).map((l) => textOf(l)).join(" ");
      if (text) return text;
    }
    const closest = el.closest("label");
    if (closest) return textOf(closest);
    if (el.id) {
      const forLabel = Array.from(el.ownerDocument.querySelectorAll("label[for]")).find(
        (l) => l.htmlFor === el.id
      );
      if (forLabel) {
        const text = textOf(forLabel);
        if (text) return text;
      }
    }
    return "";
  }
  function directLegend(fieldset) {
    return Array.from(fieldset.children).find((c) => c.tagName === "LEGEND") ?? null;
  }
  function previousText(el, maxNodes = 6) {
    let node = el;
    const parts = [];
    for (let i = 0; i < maxNodes && node; i++) {
      node = node.previousSibling;
      if (!node) break;
      if (node.nodeType === Node.TEXT_NODE) {
        const t = cleanLabel(node.textContent);
        if (t) parts.unshift(t);
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const e = node;
        if (e.matches("input, select, textarea, button")) continue;
        const t = textOf(e);
        if (t) parts.unshift(t);
        if (t.length > 60) break;
      }
    }
    return parts.join(" ").slice(0, 200);
  }
  function tableHeader(el) {
    const tr = el.closest("tr");
    if (!tr) return "";
    const th = tr.querySelector("th");
    return th ? textOf(th) : "";
  }
  function placeholderOf(el) {
    return cleanLabel(el.getAttribute("placeholder") || el.getAttribute("aria-placeholder"));
  }
  function inputTypeOf(el) {
    return (el.getAttribute("type") || "text").toLowerCase();
  }
  function kindOf(el) {
    if (el instanceof HTMLSelectElement) return { kind: "select", inputType: "select" };
    if (el instanceof HTMLTextAreaElement) return { kind: "textarea", inputType: "textarea" };
    if (el.isContentEditable) return { kind: "contenteditable", inputType: "contenteditable" };
    if (el instanceof HTMLInputElement) {
      const type = inputTypeOf(el);
      switch (type) {
        case "hidden":
        case "password":
        case "submit":
        case "button":
        case "reset":
        case "image":
          return null;
        case "email":
          return { kind: "email", inputType: type };
        case "tel":
          return { kind: "tel", inputType: type };
        case "url":
          return { kind: "url", inputType: type };
        case "number":
          return { kind: "number", inputType: type };
        case "date":
        case "datetime-local":
        case "month":
          return { kind: "date", inputType: type };
        case "file":
          return { kind: "file", inputType: type };
        case "checkbox":
          return { kind: "checkbox", inputType: type };
        case "radio":
          return { kind: "radio", inputType: type };
        case "search":
        case "text":
        default:
          if (el.getAttribute("role") === "combobox" || el.getAttribute("aria-haspopup") === "listbox") {
            return {
              kind: "unsupported",
              inputType: type,
              unsupportedReason: "\u81EA\u5B9A\u4E49\u4E0B\u62C9\u7EC4\u4EF6\uFF08\u975E\u539F\u751F select\uFF09\uFF0C\u6682\u4E0D\u652F\u6301\u81EA\u52A8\u586B\u5199"
            };
          }
          return { kind: "text", inputType: type };
      }
    }
    const role = el.getAttribute("role");
    if (role === "combobox" || role === "listbox") {
      return { kind: "unsupported", inputType: role, unsupportedReason: "\u81EA\u5B9A\u4E49\u4E0B\u62C9\u7EC4\u4EF6\uFF0C\u6682\u4E0D\u652F\u6301\u81EA\u52A8\u586B\u5199" };
    }
    if (role === "checkbox") return { kind: "checkbox", inputType: "role-checkbox" };
    if (role === "radio") return { kind: "radio", inputType: "role-radio" };
    if (role === "textbox") return { kind: "contenteditable", inputType: "role-textbox" };
    return null;
  }
  function optionLabelFor(input) {
    const fromLabels = labelFromLabels(input);
    if (fromLabels) return fromLabels;
    let node = input.nextSibling;
    while (node) {
      if (node.nodeType === Node.TEXT_NODE) {
        const t = cleanLabel(node.textContent);
        if (t) return t;
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const e = node;
        if (!e.matches("input, select, textarea, button")) {
          const t = textOf(e);
          if (t) return t;
        }
      }
      node = node.nextSibling;
    }
    return cleanLabel(input.value);
  }
  function selectOptions(select) {
    return Array.from(select.options).filter(
      (o) => !(/^(请选择|选择|select|choose|please select|—|--|-)/i.test(cleanLabel(o.text)) && (!o.value || o.value === "0" || o.value === "-1"))
    ).slice(0, 200).map((o) => ({
      label: cleanLabel(o.text) || o.value,
      value: o.value,
      disabled: o.disabled,
      checked: o.selected
    }));
  }
  function commonAncestor(elements) {
    if (!elements.length) return null;
    let node = elements[0].parentElement;
    while (node) {
      if (elements.every((el) => node.contains(el))) return node;
      node = node.parentElement;
    }
    return null;
  }
  function groupLabel(elements, name) {
    const first = elements[0];
    const fieldset = first.closest("fieldset");
    if (fieldset) {
      const text = textOf(directLegend(fieldset));
      if (text) return text;
    }
    const group = first.closest('[role="group"], [role="radiogroup"]');
    if (group) {
      const aria = labelFromAria(group);
      if (aria) return aria;
    }
    const container = commonAncestor(elements);
    if (container) {
      const heading = container.querySelector('h1,h2,h3,h4,h5,h6,[class*="title"],[class*="label"]');
      const text = textOf(heading);
      if (text && text.length <= 120) return text;
      const before = previousText(container);
      if (before) return before;
      const ownText = textOf(container);
      if (ownText && ownText.length <= 80) return ownText;
    }
    return humanizeName(name);
  }
  function headingsFor(doc) {
    return Array.from(
      doc.querySelectorAll(
        'h1,h2,h3,h4,h5,h6,legend,summary,[role="heading"],[class*="section-title"],[class*="sectionTitle"],[class*="step-title"],[class*="form-title"]'
      )
    ).filter((h) => {
      if (h.closest("label")) return false;
      const t = textOf(h);
      return t.length >= 2 && t.length <= 100;
    });
  }
  function ancestorHint(el) {
    let node = el.parentElement;
    for (let depth = 0; depth < 8 && node; depth++) {
      const id = node.id || "";
      const cls = typeof node.className === "string" ? node.className : "";
      const hay = `${id} ${cls}`;
      if (/educat|school|experience|employ|intern|project|campus|activit|skill|certif|award|honor|personal|contact|basic|教育|学历|实习|工作|项目|校园|技能|证书|荣誉|奖励|个人|联系|基本/.test(
        hay
      )) {
        return humanizeName(id || cls).slice(0, 80);
      }
      node = node.parentElement;
    }
    return "";
  }
  function nearestHeading(el, headings) {
    let best = "";
    for (const h of headings) {
      if (h.contains(el)) continue;
      const pos = h.compareDocumentPosition(el);
      if (pos & Node.DOCUMENT_POSITION_FOLLOWING) {
        best = textOf(h);
      }
    }
    return best.slice(0, 100);
  }
  function inferSection(el, headings, frameLabel = "") {
    const parts = [];
    if (frameLabel) parts.push(frameLabel);
    const fieldset = el.closest("fieldset");
    if (fieldset) {
      const legend = textOf(directLegend(fieldset));
      if (legend) parts.push(legend);
    }
    const group = el.closest('[role="group"], [role="radiogroup"]');
    if (group) {
      const aria = labelFromAria(group);
      if (aria) parts.push(aria);
    }
    const hint = ancestorHint(el);
    if (hint) parts.push(hint);
    const heading = nearestHeading(el, headings);
    if (heading) parts.push(heading);
    return Array.from(new Set(parts.filter(Boolean))).join(" | ").slice(0, 300);
  }
  function classSignature(node) {
    const cls = typeof node.className === "string" ? node.className.trim().split(/\s+/).sort().join(".") : "";
    const role = node.getAttribute("role") ?? "";
    const id = node.id ? node.id.replace(/\d+/g, "#") : "";
    return `${node.tagName}.${cls}.${role}.${id}`;
  }
  function depthOf(node) {
    let d = 0;
    let n = node;
    while (n) {
      d++;
      n = n.parentElement;
    }
    return d;
  }
  function isRepeatableNode(node) {
    const cls = typeof node.className === "string" ? node.className.trim() : "";
    const role = node.getAttribute("role") ?? "";
    if (!cls && !node.id && !role) return false;
    if (node.tagName === "FIELDSET" || node.tagName === "FORM") return false;
    if (/(^|\s)(section|form-section|step|panel|tab-pane|card-section)(\s|$)/i.test(cls)) return false;
    if (Array.from(node.children).some((c) => /^(LEGEND|H1|H2|H3|H4)$/.test(c.tagName))) return false;
    return true;
  }
  function inferRepeatIndex(el, group, frameLabel = "") {
    const numeric = (el.getAttribute("name") || el.id || "").match(/(?:^|[_[\]-])(\d{1,2})(?:$|[_[\]-])/);
    if (numeric && group) {
      const n = Number(numeric[1]);
      if (n >= 1 && n <= 10) return n - 1;
    }
    if (!group) return void 0;
    const words = GROUP_WORDS[group];
    let node = el.parentElement;
    const candidates = [];
    while (node && node !== el.ownerDocument.body) {
      const parent = node.parentElement;
      if (parent && parent.children.length >= 2 && parent.children.length <= 12 && isRepeatableNode(node)) {
        const sig = classSignature(node);
        const same = Array.from(parent.children).filter(
          (c) => c instanceof HTMLElement && classSignature(c) === sig
        );
        if (same.length >= 2 && same.length <= 10) {
          const controls = node.querySelectorAll("input, select, textarea").length;
          if (controls >= 1) {
            const text = (node.textContent || "").slice(0, 400);
            candidates.push({
              index: same.indexOf(node),
              depth: depthOf(node),
              controls,
              inGroup: words.test(text) || words.test(humanizeName(node.className || "")) || words.test(frameLabel)
            });
          }
        }
      }
      node = node.parentElement;
    }
    if (!candidates.length) return void 0;
    const grouped = candidates.filter((c) => c.inGroup && c.controls >= 2);
    const pool = grouped.length ? grouped : candidates.filter((c) => c.controls >= 2);
    if (!pool.length) return void 0;
    pool.sort((a, b) => a.depth - b.depth);
    return pool[0].index;
  }
  function containerFor(el) {
    return el.closest(
      'fieldset, [role="group"], [role="radiogroup"], .form-group, .form-item, .field, .input-group, .input-wrapper, td, li'
    ) ?? el.parentElement;
  }
  function contextFor(el) {
    const container = containerFor(el);
    if (!container) return "";
    const text = (container.textContent || "").replace(/\s+/g, " ").trim();
    return text.slice(0, 300);
  }
  function requiredOf(el, labelRaw) {
    if (el.getAttribute("aria-required") === "true") return true;
    if (el instanceof HTMLInputElement || el instanceof HTMLSelectElement || el instanceof HTMLTextAreaElement) {
      if (el.required) return true;
    }
    return /[*＊]|必填|required/i.test(labelRaw);
  }
  function currentValueOf(el, kind) {
    if (el instanceof HTMLInputElement) {
      if (kind === "checkbox" || kind === "radio") return el.checked ? "true" : "";
      return el.value;
    }
    if (el instanceof HTMLSelectElement) {
      const selected = el.selectedOptions?.[0] ?? el.options[el.selectedIndex];
      const label = (selected?.text ?? "").trim();
      if (!el.value || /^(请选择|选择|select|choose|please select|—|--|-)/i.test(label)) return "";
      return el.value;
    }
    if (el instanceof HTMLTextAreaElement) return el.value;
    if (el.isContentEditable) return (el.textContent || "").trim();
    return "";
  }
  var fieldCounter = 0;
  function nextId(prefix) {
    fieldCounter += 1;
    return `${prefix}field_${fieldCounter}`;
  }
  function pushField(input) {
    const {
      el,
      elements,
      kind,
      inputType,
      label,
      labelRaw,
      placeholder,
      options,
      container,
      section,
      sectionGroup,
      repeatIndex,
      prefix,
      unsupportedReason
    } = input;
    const name = el.getAttribute("name") ?? "";
    const id = el.id ?? "";
    const required = elements.some((e) => requiredOf(e, labelRaw)) || requiredOf(el, labelRaw);
    const maxLength = el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement ? el.maxLength > 0 ? el.maxLength : void 0 : void 0;
    const pattern = el.getAttribute("pattern") ?? void 0;
    const autocomplete = el.getAttribute("autocomplete") ?? "";
    const currentValue = currentValueOf(el, kind);
    const visible = elements.length > 1 ? elements.some((e) => isVisible(e)) : elements.length === 1 ? isVisible(elements[0]) : isVisible(el);
    const field = {
      fieldId: nextId(prefix),
      kind,
      inputType,
      name,
      id,
      label,
      placeholder,
      ariaLabel: cleanLabel(el.getAttribute("aria-label")),
      autocomplete,
      required,
      disabled: elements.length ? elements.every((e) => e.disabled) : el.disabled === true,
      readOnly: el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement ? el.readOnly : false,
      visible,
      maxLength,
      pattern,
      options,
      section,
      sectionGroup,
      repeatIndex,
      contextText: contextFor(el),
      currentValue,
      hasUserValue: !isBlank(currentValue),
      unsupportedReason
    };
    const initialChecked = elements.filter((e) => e.checked).map((e) => e.value);
    registry.set(field.fieldId, {
      field,
      primary: el,
      elements,
      container: container ?? el.parentElement,
      initialValue: currentValue,
      initialChecked,
      lastFilled: void 0
    });
    return field;
  }
  function processGroup(elements, kind, doc, headings, frameLabel, prefix) {
    const visibleEls = elements.filter((e) => isVisible(e) && !e.disabled);
    if (!visibleEls.length) return null;
    const first = elements[0];
    const name = first.getAttribute("name") ?? "";
    const options = elements.map((e) => ({
      label: optionLabelFor(e),
      value: e.value,
      checked: e.checked,
      disabled: e.disabled
    }));
    const rawLabel = groupLabel(elements, name);
    const fieldset = first.closest("fieldset");
    const labelRaw = fieldset ? textOf(directLegend(fieldset)) : rawLabel;
    const section = inferSection(first, headings, frameLabel);
    const sectionGroup = classifySection(section);
    const container = commonAncestor(elements) ?? containerFor(first);
    const currentValue = elements.filter((e) => e.checked).map((e) => optionLabelFor(e)).join(", ");
    const field = pushField({
      el: first,
      elements,
      kind,
      inputType: kind,
      label: rawLabel,
      labelRaw,
      placeholder: "",
      options,
      container,
      section,
      sectionGroup,
      repeatIndex: inferRepeatIndex(first, sectionGroup, frameLabel),
      prefix
    });
    field.currentValue = currentValue;
    field.hasUserValue = elements.some((e) => e.checked);
    const entry = registry.get(field.fieldId);
    if (entry) entry.initialValue = currentValue;
    return field;
  }
  function scanDocument(doc, prefix, depth, stats, fields, frameLabel = "") {
    const headings = headingsFor(doc);
    const candidates = Array.from(
      doc.querySelectorAll(
        'input, textarea, select, [contenteditable="true"], [contenteditable=""], [role="textbox"], [role="combobox"], [role="listbox"]'
      )
    ).filter((el) => !el.closest("#applymate-panel-host"));
    const radioGroups = /* @__PURE__ */ new Map();
    const checkboxGroups = /* @__PURE__ */ new Map();
    const formIndex = (el) => {
      const form = el.form;
      if (!form) return "noform";
      return String(Array.from(doc.forms).indexOf(form));
    };
    for (const el of candidates) {
      if (!(el instanceof HTMLInputElement)) continue;
      const type = inputTypeOf(el);
      if (type !== "radio" && type !== "checkbox") continue;
      const name = el.getAttribute("name");
      if (!name) continue;
      const key = `${prefix}:${formIndex(el)}:${name}`;
      const map = type === "radio" ? radioGroups : checkboxGroups;
      const list = map.get(key) ?? [];
      list.push(el);
      map.set(key, list);
    }
    const processed = /* @__PURE__ */ new Set();
    for (const el of candidates) {
      if (processed.has(el)) continue;
      if (el instanceof HTMLInputElement) {
        const type = inputTypeOf(el);
        if (type === "radio" || type === "checkbox") {
          const name = el.getAttribute("name");
          const key = name ? `${prefix}:${formIndex(el)}:${name}` : "";
          const group = key ? (type === "radio" ? radioGroups : checkboxGroups).get(key) ?? [] : [];
          if (group.length > 1) {
            group.forEach((e) => processed.add(e));
            const field = processGroup(group, type, doc, headings, frameLabel, prefix);
            if (field) fields.push(field);
          } else {
            processed.add(el);
            if (!isVisible(el)) continue;
            const aria2 = labelFromAria(el);
            const labels = labelFromLabels(el);
            const optionLabel = aria2 || labels || optionLabelFor(el);
            const label2 = optionLabel || humanizeName(name || el.id);
            const section2 = inferSection(el, headings, frameLabel);
            const sectionGroup2 = classifySection(section2);
            fields.push(
              pushField({
                el,
                elements: [el],
                kind: type,
                inputType: type,
                label: label2,
                labelRaw: optionLabel,
                placeholder: "",
                options: [{ label: optionLabel || el.value, value: el.value, checked: el.checked, disabled: el.disabled }],
                container: containerFor(el),
                section: section2,
                sectionGroup: sectionGroup2,
                repeatIndex: inferRepeatIndex(el, sectionGroup2, frameLabel),
                prefix
              })
            );
          }
          continue;
        }
      }
      const kindInfo = kindOf(el);
      if (!kindInfo) {
        processed.add(el);
        continue;
      }
      processed.add(el);
      if (!isVisible(el)) continue;
      const aria = labelFromAria(el);
      const fromLabels = el instanceof HTMLInputElement || el instanceof HTMLSelectElement || el instanceof HTMLTextAreaElement ? labelFromLabels(el) : "";
      const table = tableHeader(el);
      const previous = previousText(el);
      const placeholder = placeholderOf(el);
      const rawLabel = aria || fromLabels || table || previous;
      const label = cleanLabel(rawLabel) || placeholder || humanizeName(el.getAttribute("name") || el.id);
      const section = inferSection(el, headings, frameLabel);
      const sectionGroup = classifySection(section);
      const options = el instanceof HTMLSelectElement ? selectOptions(el) : kindInfo.kind === "checkbox" || kindInfo.kind === "radio" ? void 0 : void 0;
      fields.push(
        pushField({
          el,
          elements: el instanceof HTMLInputElement ? [el] : [],
          kind: kindInfo.kind,
          inputType: kindInfo.inputType,
          label,
          labelRaw: rawLabel || placeholder,
          placeholder,
          options,
          container: containerFor(el),
          section,
          sectionGroup,
          repeatIndex: inferRepeatIndex(el, sectionGroup, frameLabel),
          prefix,
          unsupportedReason: kindInfo.unsupportedReason
        })
      );
    }
    if (depth < 1) {
      const frames = Array.from(doc.querySelectorAll("iframe"));
      frames.forEach((frame, idx) => {
        stats.total += 1;
        let frameDoc = null;
        try {
          frameDoc = frame.contentDocument;
        } catch {
          frameDoc = null;
        }
        if (!frameDoc) {
          stats.crossOrigin += 1;
          return;
        }
        stats.sameOriginScanned += 1;
        const label = `iframe: ${cleanLabel(frame.getAttribute("title") || frame.getAttribute("name") || `frame ${idx + 1}`)}`;
        scanDocument(frameDoc, `${prefix}if${idx}_`, depth + 1, stats, fields, label);
      });
    }
  }
  function scanPage() {
    registry.clear();
    fieldCounter = 0;
    const stats = { total: 0, crossOrigin: 0, sameOriginScanned: 0 };
    const fields = [];
    try {
      scanDocument(document, "", 0, stats, fields);
    } catch (e) {
      console.warn("[ApplyMate] scan failed", e);
    }
    try {
      const marker = document.querySelector("#applymate-panel-host");
      if (marker) marker.remove();
    } catch {
    }
    return {
      fields,
      title: document.title,
      url: location.href,
      iframes: stats
    };
  }

  // src/content/filler.ts
  var splitValues = (v) => {
    if (v == null) return [];
    if (Array.isArray(v)) return v.map(String).filter(Boolean);
    return String(v).split(/\s*(?:[;；,，、|]\s*)+/).map((s) => s.trim()).filter(Boolean);
  };
  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function setNativeSelect(el, value) {
    const target = Array.from(el.options).find((o) => o.value === value);
    if (target) {
      target.selected = true;
      if (!el.multiple) {
        for (const o of Array.from(el.options)) if (o !== target) o.selected = false;
      }
    }
    const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function checkedValues(entry) {
    return entry.elements.filter((e) => e.checked).map((e) => e.value).sort();
  }
  var sameSet = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
  function isUserModified(entry) {
    const field = entry.field;
    if (field.kind === "radio" || field.kind === "checkbox") {
      const current2 = checkedValues(entry);
      if (!current2.length) return false;
      if (sameSet(current2, [...entry.initialChecked].sort())) return false;
      if (entry.lastFilledChoices && sameSet(current2, [...entry.lastFilledChoices].sort())) return false;
      return true;
    }
    const current = readValue(entry.primary, field);
    if (!current.trim()) return false;
    if (current === entry.initialValue) return false;
    if (entry.lastFilled != null && current === entry.lastFilled) return false;
    return true;
  }
  function readValue(el, field) {
    if (el instanceof HTMLInputElement) return field.kind === "checkbox" || field.kind === "radio" ? el.checked ? "true" : "" : el.value;
    if (el instanceof HTMLSelectElement) {
      const selected = el.selectedOptions?.[0] ?? el.options[el.selectedIndex];
      const label = (selected?.text ?? "").trim();
      if (!el.value || /^(请选择|选择|select|choose|please select|—|--|-)/i.test(label)) return "";
      return el.value;
    }
    if (el instanceof HTMLTextAreaElement) return el.value;
    return (el.textContent || "").trim();
  }
  function preview(value) {
    const s = Array.isArray(value) ? value.join(", ") : value ?? "";
    return s.length > 60 ? `${s.slice(0, 60)}\u2026` : s;
  }
  function optionListForEntry(entry) {
    return entry.elements.map((e) => ({
      label: e.labels?.[0]?.textContent?.trim() || e.closest("label")?.textContent?.trim() || e.value,
      value: e.value,
      disabled: e.disabled
    }));
  }
  function chooseRadio(entry, mapping) {
    const options = optionListForEntry(entry);
    let targetValue = mapping.optionValue;
    if (!targetValue && mapping.value != null) {
      const m = matchOption(String(mapping.value), options);
      targetValue = m?.option.value;
    }
    if (!targetValue) {
      const nv = normalizeText(String(mapping.value ?? ""));
      targetValue = options.find((o) => normalizeText(o.label) === nv || normalizeText(o.value) === nv)?.value;
    }
    if (!targetValue) return false;
    const target = entry.elements.find((e) => e.value === targetValue);
    if (!target) return false;
    if (!target.checked) target.click();
    entry.lastFilledChoices = [target.value];
    return target.checked;
  }
  function fillCheckbox(entry, mapping) {
    const options = optionListForEntry(entry);
    let desired = mapping.optionValues?.filter(Boolean) ?? [];
    if (!desired.length && mapping.value != null) {
      const requested = Array.isArray(mapping.value) ? mapping.value : splitValues(mapping.value);
      desired = requested.map((v) => matchOption(String(v), options)?.option.value).filter((v) => Boolean(v));
    }
    if (!desired.length) {
      const nv = normalizeText(String(mapping.value ?? ""));
      if (/^(yes|y|true|是|同意|愿意|agree)$/.test(nv)) desired = [entry.elements[0]?.value].filter(Boolean);
      else return false;
    }
    let touched = false;
    for (const el of entry.elements) {
      const should = desired.includes(el.value);
      if (should && !el.checked) {
        el.click();
        touched = true;
      } else if (!should && el.checked && entry.lastFilledChoices?.includes(el.value)) {
        el.click();
        touched = true;
      }
    }
    entry.lastFilledChoices = checkedValues(entry);
    return touched || desired.every((v) => entry.elements.find((e) => e.value === v)?.checked);
  }
  function fillSelect(entry, mapping) {
    const el = entry.primary;
    if (!(el instanceof HTMLSelectElement)) return false;
    const options = Array.from(el.options).filter((o) => !o.disabled).map((o) => ({ label: o.text.trim(), value: o.value }));
    let targetValue = mapping.optionValue;
    if (!targetValue) {
      const m = matchOption(String(mapping.value ?? ""), options);
      targetValue = m?.option.value;
    }
    if (!targetValue) {
      const nv = normalizeText(String(mapping.value ?? ""));
      targetValue = options.find((o) => normalizeText(o.label) === nv || normalizeText(o.value) === nv)?.value;
    }
    if (targetValue == null) return false;
    setNativeSelect(el, targetValue);
    if (el.multiple) {
      const wanted = new Set(mapping.optionValues ?? [targetValue]);
      for (const o of Array.from(el.options)) o.selected = wanted.has(o.value);
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    entry.lastFilled = el.value;
    return el.value === targetValue;
  }
  function fillContentEditable(el, value) {
    el.focus();
    try {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(el);
      selection?.removeAllRanges();
      selection?.addRange(range);
      const ok = document.execCommand("insertText", false, value);
      if (!ok) el.textContent = value;
    } catch {
      el.textContent = value;
    }
    el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: value }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return (el.textContent || "").includes(value.slice(0, Math.min(10, value.length)));
  }
  function fillOne(entry, mapping) {
    const field = entry.field;
    const el = entry.primary;
    const raw = mapping.value;
    if (raw == null) return { ok: false, message: "\u6CA1\u6709\u53EF\u586B\u5199\u7684\u5185\u5BB9" };
    if (field.kind === "radio") {
      return chooseRadio(entry, mapping) ? { ok: true, value: entry.lastFilledChoices?.join(", ") } : { ok: false, message: "\u9875\u9762\u5355\u9009\u9879\u4E2D\u627E\u4E0D\u5230\u5339\u914D\u9879" };
    }
    if (field.kind === "checkbox") {
      return fillCheckbox(entry, mapping) ? { ok: true, value: entry.lastFilledChoices?.join(", ") } : { ok: false, message: "\u9875\u9762\u590D\u9009\u9879\u4E2D\u627E\u4E0D\u5230\u5339\u914D\u9879" };
    }
    if (field.kind === "select") {
      return fillSelect(entry, mapping) ? { ok: true, value: entry.lastFilled } : { ok: false, message: "\u9875\u9762\u4E0B\u62C9\u9009\u9879\u4E2D\u627E\u4E0D\u5230\u5339\u914D\u9879" };
    }
    let value = Array.isArray(raw) ? raw.join(", ") : String(raw);
    if (field.kind === "date") {
      value = formatDateForField(value, {
        inputType: field.inputType,
        placeholder: field.placeholder,
        label: field.label
      });
    }
    if (field.kind === "number" && !/^-?\d+(\.\d+)?$/.test(value.trim())) {
      return { ok: false, message: "\u8BE5\u5B57\u6BB5\u53EA\u63A5\u53D7\u6570\u5B57" };
    }
    if (field.maxLength && field.maxLength > 0 && value.length > field.maxLength) {
      return { ok: false, message: `\u5185\u5BB9\u8D85\u51FA\u9875\u9762\u957F\u5EA6\u9650\u5236\uFF08${field.maxLength}\uFF09` };
    }
    if (field.kind === "contenteditable") {
      return fillContentEditable(el, value) ? { ok: true, value } : { ok: false, message: "\u5BCC\u6587\u672C\u7F16\u8F91\u5668\u5199\u5165\u5931\u8D25\uFF0C\u8BF7\u624B\u52A8\u586B\u5199" };
    }
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)) {
      return { ok: false, message: "\u65E0\u6CD5\u8BC6\u522B\u7684\u8F93\u5165\u63A7\u4EF6" };
    }
    if (el.readOnly) return { ok: false, message: "\u5B57\u6BB5\u4E3A\u53EA\u8BFB\uFF0C\u65E0\u6CD5\u586B\u5199" };
    el.focus({ preventScroll: true });
    setNativeValue(el, value);
    entry.lastFilled = el.value;
    return el.value === value ? { ok: true, value } : { ok: false, message: "\u9875\u9762\u672A\u80FD\u63A5\u53D7\u8BE5\u503C\uFF0C\u53EF\u80FD\u9700\u8981\u624B\u52A8\u8F93\u5165" };
  }
  function fillMappings(mappings, options = {}) {
    const results = [];
    let filled = 0;
    let failed = 0;
    let skipped = 0;
    let needsConfirmation = 0;
    let unsupported = 0;
    for (const mapping of mappings) {
      const entry = registry.get(mapping.fieldId);
      const label = mapping.fieldLabel || entry?.field.label || mapping.fieldId;
      if (!entry) {
        results.push({ fieldId: mapping.fieldId, label, status: "failed", message: "\u9875\u9762\u7ED3\u6784\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u8BC6\u522B" });
        failed++;
        continue;
      }
      if (mapping.status === "unsupported") {
        results.push({ fieldId: mapping.fieldId, label, status: "unsupported", message: mapping.note || "\u6682\u4E0D\u652F\u6301\u81EA\u52A8\u586B\u5199" });
        unsupported++;
        continue;
      }
      if (mapping.status === "skipped_user_value") {
        results.push({ fieldId: mapping.fieldId, label, status: "skipped", message: mapping.note || "\u4FDD\u7559\u60A8\u5DF2\u586B\u5199\u7684\u5185\u5BB9" });
        skipped++;
        continue;
      }
      if (mapping.status === "missing" || mapping.value == null) {
        results.push({ fieldId: mapping.fieldId, label, status: "skipped", message: mapping.note || "\u6CA1\u6709\u53EF\u7528\u8D44\u6599" });
        skipped++;
        continue;
      }
      if (!options.overrideUserValues && isUserModified(entry)) {
        results.push({ fieldId: mapping.fieldId, label, status: "user_modified", message: "\u68C0\u6D4B\u5230\u60A8\u5DF2\u4FEE\u6539\u8BE5\u5B57\u6BB5\uFF0C\u672A\u8986\u76D6" });
        skipped++;
        continue;
      }
      const before = readValue(entry.primary, entry.field);
      if ((entry.field.kind === "text" || entry.field.kind === "email" || entry.field.kind === "tel" || entry.field.kind === "textarea" || entry.field.kind === "url") && entry.lastFilled != null && before === entry.lastFilled) {
        results.push({ fieldId: mapping.fieldId, label, status: "skipped", message: "\u5DF2\u586B\u5199\u76F8\u540C\u5185\u5BB9" });
        skipped++;
        continue;
      }
      const result = fillOne(entry, mapping);
      if (result.ok) {
        filled++;
        const status = mapping.requiresConfirmation ? "needs_confirmation" : "filled";
        if (mapping.requiresConfirmation) needsConfirmation++;
        results.push({
          fieldId: mapping.fieldId,
          label,
          status,
          valuePreview: preview(mapping.value),
          message: mapping.requiresConfirmation ? mapping.note || "\u8BF7\u6838\u5BF9\u586B\u5199\u5185\u5BB9" : void 0
        });
      } else {
        failed++;
        results.push({ fieldId: mapping.fieldId, label, status: "failed", message: result.message });
      }
    }
    const requiredMissing = [];
    for (const entry of registry.values()) {
      if (!entry.field.required) continue;
      let empty = false;
      if (entry.field.kind === "radio" || entry.field.kind === "checkbox") {
        empty = !entry.elements.some((e) => e.checked);
      } else {
        empty = !readValue(entry.primary, entry.field).trim();
      }
      if (empty && !requiredMissing.includes(entry.field.label || entry.field.fieldId)) {
        requiredMissing.push(entry.field.label || entry.field.fieldId);
      }
    }
    return {
      results,
      filled,
      failed,
      skipped,
      needsConfirmation,
      unsupported,
      requiredMissing,
      unsupportedIframes: options.unsupportedIframes ?? 0,
      url: location.href,
      host: location.host,
      title: document.title,
      filledAt: (/* @__PURE__ */ new Date()).toISOString(),
      submitted: false
    };
  }

  // ../packages/shared/src/summary.ts
  function buildMappingSummary(mappings) {
    const s = {
      total: mappings.length,
      matched: 0,
      needsReview: 0,
      missing: 0,
      unsupported: 0,
      skipped: 0
    };
    for (const m of mappings) {
      switch (m.status) {
        case "matched":
          s.matched++;
          break;
        case "needs_review":
          s.needsReview++;
          break;
        case "missing":
          s.missing++;
          break;
        case "unsupported":
          s.unsupported++;
          break;
        case "skipped_user_value":
          s.skipped++;
          break;
      }
    }
    return s;
  }

  // src/content/highlighter.ts
  var TONES = {
    green: { color: "#16a34a", bg: "rgba(22, 163, 74, 0.06)" },
    amber: { color: "#d97706", bg: "rgba(217, 119, 6, 0.08)" },
    slate: { color: "#94a3b8", bg: "rgba(148, 163, 184, 0.08)" }
  };
  var STATUS_BY_FIELD = /* @__PURE__ */ new Map();
  function applyHighlights(report, mappings) {
    const byId = new Map(mappings.map((m) => [m.fieldId, m]));
    for (const result of report.results) {
      const entry = registry.get(result.fieldId);
      const mapping = byId.get(result.fieldId);
      if (!entry) continue;
      let tone;
      if (result.status === "needs_confirmation" || result.status === "filled" && mapping?.requiresConfirmation) tone = "amber";
      else if (result.status === "filled") tone = "green";
      else tone = "slate";
      const target = entry.field.kind === "radio" || entry.field.kind === "checkbox" ? entry.container || entry.primary : entry.primary;
      if (!target) continue;
      const backup = entry.styleBackup ?? [];
      if (!backup.some((b) => b.el === target)) {
        backup.push({
          el: target,
          outline: target.style.outline,
          backgroundColor: target.style.backgroundColor,
          outlineOffset: target.style.outlineOffset
        });
      }
      entry.styleBackup = backup;
      target.style.setProperty("outline", `2px solid ${TONES[tone].color}`, "important");
      target.style.setProperty("outline-offset", "2px", "important");
      target.style.setProperty("background-color", TONES[tone].bg, "important");
      target.setAttribute("data-applymate-status", tone);
      STATUS_BY_FIELD.set(result.fieldId, tone);
    }
  }
  function clearHighlights() {
    for (const entry of registry.values()) {
      for (const backup of entry.styleBackup ?? []) {
        if (!backup.el.isConnected) continue;
        backup.el.style.setProperty("outline", backup.outline);
        backup.el.style.setProperty("background-color", backup.backgroundColor);
        backup.el.style.setProperty("outline-offset", backup.outlineOffset);
        backup.el.removeAttribute("data-applymate-status");
      }
      entry.styleBackup = [];
    }
    STATUS_BY_FIELD.clear();
  }
  function removePanel() {
    document.getElementById("applymate-panel-host")?.remove();
  }
  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c);
  }
  function showResultPanel(report, mappings) {
    removePanel();
    const summary = buildMappingSummary(mappings);
    const host = document.createElement("div");
    host.id = "applymate-panel-host";
    host.style.cssText = "all:initial;position:fixed;right:20px;bottom:20px;z-index:2147483647;";
    const shadow = host.attachShadow({ mode: "open" });
    const missingRequired = report.requiredMissing.slice(0, 6);
    shadow.innerHTML = `
    <style>
      :host { all: initial; }
      .panel {
        width: 316px; background: #ffffff; color: #0f172a;
        border: 1px solid #e2e8f0; border-radius: 16px;
        box-shadow: 0 18px 50px -12px rgba(15,23,42,.35), 0 2px 8px rgba(15,23,42,.08);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
        overflow: hidden; animation: rise .24s ease-out;
      }
      @keyframes rise { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
      .head { display:flex; align-items:center; justify-content:space-between; padding: 12px 14px; border-bottom:1px solid #eef2f7; background: linear-gradient(180deg,#f8fbff,#fff); }
      .brand { display:flex; align-items:center; gap:8px; font-weight:700; font-size:13px; letter-spacing:.01em; }
      .dot { width:22px; height:22px; border-radius:7px; background:#2563eb; display:flex; align-items:center; justify-content:center; }
      .dot svg { width:13px; height:13px; }
      .close { border:0; background:transparent; color:#94a3b8; cursor:pointer; font-size:18px; line-height:1; padding:4px 6px; border-radius:6px; }
      .close:hover { background:#f1f5f9; color:#0f172a; }
      .body { padding: 12px 14px 6px; }
      .stats { display:flex; gap:6px; margin-bottom:10px; }
      .stat { flex:1; border-radius:10px; padding:7px 8px; text-align:center; border:1px solid transparent; }
      .stat b { display:block; font-size:17px; line-height:1.2; }
      .stat span { font-size:10px; color:#64748b; }
      .green { background:#ecfdf5; border-color:#bbf7d0; color:#047857; }
      .amber { background:#fffbeb; border-color:#fde68a; color:#b45309; }
      .slate { background:#f1f5f9; border-color:#e2e8f0; color:#475569; }
      .note { font-size:11px; color:#64748b; line-height:1.55; margin: 2px 0 8px; }
      .warn { background:#fffbeb; color:#92400e; border:1px solid #fde68a; border-radius:8px; padding:7px 9px; font-size:11px; line-height:1.5; margin-bottom:8px; }
      .req { font-size:11px; color:#b45309; margin-bottom:8px; line-height:1.5; }
      .actions { display:flex; gap:7px; padding: 4px 14px 14px; }
      button.act { flex:1; font: 600 12px/1 inherit; font-family: inherit; border-radius:9px; padding:9px 10px; cursor:pointer; border:1px solid transparent; transition: background .15s; }
      .primary { background:#2563eb; color:#fff; }
      .primary:hover { background:#1d4ed8; }
      .secondary { background:#fff; color:#334155; border-color:#e2e8f0 !important; }
      .secondary:hover { background:#f8fafc; }
      .foot { font-size:10px; color:#94a3b8; padding: 0 14px 12px; line-height:1.5; }
      .mock { display:inline-block; font-size:9px; font-weight:700; letter-spacing:.06em; background:#fef3c7; color:#92400e; border-radius:4px; padding:1px 4px; margin-left:4px; }
    </style>
    <div class="panel" role="dialog" aria-label="ApplyMate \u586B\u5199\u7ED3\u679C">
      <div class="head">
        <div class="brand">
          <span class="dot"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span>
          ApplyMate \u586B\u5199\u7ED3\u679C
        </div>
        <button class="close" id="close" aria-label="\u5173\u95ED">\xD7</button>
      </div>
      <div class="body">
        <div class="stats">
          <div class="stat green"><b>${report.filled}</b><span>\u5DF2\u586B\u5199</span></div>
          <div class="stat amber"><b>${report.needsConfirmation}</b><span>\u5F85\u6838\u5BF9</span></div>
          <div class="stat slate"><b>${summary.missing + summary.unsupported + report.failed}</b><span>\u672A\u586B\u5199</span></div>
        </div>
        ${missingRequired.length ? `<div class="req">\u5FC5\u586B\u9879\u5C1A\u672A\u5B8C\u6210\uFF1A${missingRequired.map(escapeHtml).join("\u3001")}${report.requiredMissing.length > missingRequired.length ? "\u2026" : ""}</div>` : ""}
        ${report.unsupportedIframes ? `<div class="warn">\u68C0\u6D4B\u5230 ${report.unsupportedIframes} \u4E2A\u8DE8\u57DF iframe\uFF0C\u5176\u4E2D\u7684\u8868\u5355\u65E0\u6CD5\u8BBF\u95EE\uFF0C\u8BF7\u624B\u52A8\u586B\u5199\u3002</div>` : ""}
        <div class="note">\u7EFF\u8272\u4E3A\u5DF2\u586B\u5199\uFF0C\u9EC4\u8272\u8BF7\u6838\u5BF9\u3002ApplyMate \u4E0D\u4F1A\u70B9\u51FB\u63D0\u4EA4\uFF0C\u4E5F\u4E0D\u4F1A\u7ED5\u8FC7\u9A8C\u8BC1\u7801\u6216\u767B\u5F55\u9A8C\u8BC1\u3002</div>
      </div>
      <div class="actions">
        <button class="act primary" id="details">\u67E5\u770B\u8BE6\u60C5</button>
        <button class="act secondary" id="rescan">\u91CD\u65B0\u8BC6\u522B</button>
      </div>
      <div class="foot">\u8BF7\u81EA\u884C\u68C0\u67E5\u9875\u9762\u5185\u5BB9\u540E\u518D\u63D0\u4EA4\u3002</div>
    </div>
  `;
    shadow.getElementById("close")?.addEventListener("click", () => host.remove());
    shadow.getElementById("details")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ __applymate: true, type: "OPEN_DASHBOARD", hash: "/result" }).catch(() => void 0);
    });
    shadow.getElementById("rescan")?.addEventListener("click", () => {
      const btn = shadow.getElementById("rescan");
      if (btn) {
        btn.disabled = true;
        btn.textContent = "\u8BC6\u522B\u4E2D\u2026";
      }
      chrome.runtime.sendMessage({ __applymate: true, type: "RESCAN" }).then((res) => {
        if (btn) {
          btn.disabled = false;
          btn.textContent = res?.ok ? "\u5DF2\u91CD\u65B0\u8BC6\u522B" : "\u91CD\u8BD5";
        }
        const note = shadow.querySelector(".note");
        if (note && res?.ok && res.data?.summary) {
          note.textContent = `\u5DF2\u91CD\u65B0\u8BC6\u522B\uFF1A\u5339\u914D ${res.data.summary.matched} \u9879\u3002\u8BF7\u70B9\u51FB\u6D4F\u89C8\u5668\u5DE5\u5177\u680F\u4E2D\u7684 ApplyMate \u56FE\u6807\uFF0C\u518D\u70B9\u51FB\u300C\u4E00\u952E\u586B\u5199\u300D\u3002`;
        } else if (note && res?.error?.message) {
          note.textContent = res.error.message;
        }
      }).catch(() => {
        if (btn) {
          btn.disabled = false;
          btn.textContent = "\u91CD\u8BD5";
        }
      });
    });
    document.documentElement.appendChild(host);
  }

  // src/content/index.ts
  var VERSION = "0.1.0";
  var lastStats = { total: 0, crossOrigin: 0, sameOriginScanned: 0 };
  function errorResponse(message) {
    return { error: { code: "CONTENT_ERROR", message } };
  }
  async function handleScan() {
    clearHighlights();
    removePanel();
    await waitForDomStable();
    const result = scanPage();
    lastStats = result.iframes;
    return result;
  }
  function handleMessage(message, _sender, sendResponse) {
    if (!message || message.__applymate !== true) return void 0;
    const msg = message;
    if (msg.type === "PING") {
      sendResponse({ ok: true, url: location.href, version: VERSION });
      return void 0;
    }
    if (msg.type === "SCAN_FORM") {
      handleScan().then(sendResponse).catch((e) => sendResponse(errorResponse(e instanceof Error ? e.message : String(e))));
      return true;
    }
    if (msg.type === "APPLY_MAPPINGS") {
      (async () => {
        try {
          const report = fillMappings(msg.mappings, {
            overrideUserValues: msg.overrideUserValues,
            unsupportedIframes: lastStats.crossOrigin
          });
          applyHighlights(report, msg.mappings);
          showResultPanel(report, msg.mappings);
          sendResponse(report);
        } catch (e) {
          sendResponse(errorResponse(e instanceof Error ? e.message : String(e)));
        }
      })();
      return true;
    }
    if (msg.type === "CLEAR_HIGHLIGHTS") {
      clearHighlights();
      removePanel();
      sendResponse({ ok: true });
      return void 0;
    }
    if (msg.type === "SHOW_SUMMARY") {
      sendResponse({ ok: true });
      return void 0;
    }
    return void 0;
  }
  var g = globalThis;
  if (g.__applymateListener) {
    try {
      chrome.runtime.onMessage.removeListener(g.__applymateListener);
    } catch {
    }
  }
  g.__applymateListener = handleMessage;
  g.__applymateInjected = true;
  chrome.runtime.onMessage.addListener(handleMessage);
})();
