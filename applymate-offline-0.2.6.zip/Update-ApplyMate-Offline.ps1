param(
  [Parameter(Mandatory=$true)][string]$Root,
  [Parameter(Mandatory=$true)][string]$DataDir
)
$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$configPath = Join-Path $Root 'update-config.json'
if (!(Test-Path $configPath)) { exit 0 }
$config = Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$feedUrl = [string]$config.feedUrl
if ([string]::IsNullOrWhiteSpace($feedUrl)) { exit 0 }

$versionsDir = Join-Path $DataDir 'versions'
$updatesDir = Join-Path $DataDir 'updates'
$versionFile = Join-Path $DataDir 'current-version.txt'
New-Item -ItemType Directory -Force -Path $versionsDir,$updatesDir | Out-Null

$currentDir = $Root
if (Test-Path $versionFile) {
  $cv = (Get-Content $versionFile -Raw).Trim()
  $candidate = Join-Path $versionsDir $cv
  if ($cv -and (Test-Path (Join-Path $candidate 'manifest.json'))) { $currentDir = $candidate }
}
$currentManifest = Get-Content (Join-Path $currentDir 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$currentVersion = [version]$currentManifest.version

try {
  $feedResponse = Invoke-WebRequest -Uri $feedUrl -Headers @{ 'User-Agent' = 'ApplyMate-Updater'; 'Accept' = 'application/vnd.github.raw' } -TimeoutSec 6 -UseBasicParsing
  $feedText = if ($feedResponse.Content -is [byte[]]) { [System.Text.Encoding]::UTF8.GetString($feedResponse.Content) } else { [string]$feedResponse.Content }
  $feed = $feedText | ConvertFrom-Json
} catch { exit 0 }
if (!$feed -or !$feed.version) { exit 0 }
$latestVersion = [version]$feed.version
if ($latestVersion -le $currentVersion) { exit 0 }

$downloadUrl = [string]$feed.downloadUrl
if ($downloadUrl -notmatch '^https?://') {
  $base = New-Object System.Uri($feedUrl)
  $downloadUrl = (New-Object System.Uri($base, $downloadUrl)).AbsoluteUri
}
$zipPath = Join-Path $updatesDir ("applymate-offline-" + $latestVersion.ToString() + ".zip")
try {
  Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath -Headers @{ 'User-Agent' = 'ApplyMate-Updater' } -TimeoutSec 60 -UseBasicParsing
} catch { exit 0 }
if ($feed.sha256) {
  $hash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
  if ($hash -ne ([string]$feed.sha256).ToLower()) { Remove-Item $zipPath -Force; exit 0 }
}
$target = Join-Path $versionsDir $latestVersion.ToString()
if (Test-Path $target) { Remove-Item $target -Recurse -Force }
Expand-Archive -LiteralPath $zipPath -DestinationPath $target -Force
if (!(Test-Path (Join-Path $target 'manifest.json'))) { exit 0 }
[System.IO.File]::WriteAllText($versionFile, $latestVersion.ToString(), (New-Object System.Text.UTF8Encoding($false)))

$running = Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" | Where-Object { $_.CommandLine -like '*ApplyMate-OfflineProfile*' }
if ($running) {
  Write-Host "ApplyMate v$latestVersion is ready. Close the ApplyMate Edge window and run the launcher again."
  exit 2
}
Write-Host "ApplyMate updated to v$latestVersion."
exit 0
