@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" (
  echo Microsoft Edge was not found. Please install Edge first.
  pause
  exit /b 1
)
set "PROFILE=%LOCALAPPDATA%\ApplyMate-OfflineProfile"
set "DATA=%LOCALAPPDATA%\ApplyMate-Offline"
if not exist "%PROFILE%" mkdir "%PROFILE%"
if not exist "%DATA%" mkdir "%DATA%"
set "EXT_DIR=%~dp0."
if exist "%~dp0Update-ApplyMate-Offline.ps1" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-ApplyMate-Offline.ps1" -Root "%~dp0." -DataDir "%DATA%"
  if errorlevel 2 (
    echo.
    echo A new version was prepared. Close the ApplyMate Edge window, then run this launcher again.
    pause
    exit /b 0
  )
)
if exist "%DATA%\current-version.txt" (
  set /p CUR_VER=<"%DATA%\current-version.txt"
  if exist "%DATA%\versions\!CUR_VER!\manifest.json" set "EXT_DIR=%DATA%\versions\!CUR_VER!"
)
start "" "%EDGE%" --user-data-dir="%PROFILE%" --disable-extensions-except="!EXT_DIR!" --load-extension="!EXT_DIR!" --no-first-run --no-default-browser-check "chrome-extension://feekflfaeiopmljagbabmmpahehkaelg/dashboard.html#/welcome"
endlocal
